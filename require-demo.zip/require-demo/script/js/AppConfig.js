require.config({
    baseUrl: 'script/js',
    paths: {
        zepto: 'libs/zepto.min',
        appCom: 'module/AppCommon',
        index: 'module/index',
        login: 'module/login'
    },
    shim: {
        zepto: {exports: 'zepto'},
        appCom: {exports: 'appCom'},
        index: {
            init: 'index'
        },
        login: {exports: 'login'}
    }
});

function MySelf(){
    alert("我是自身的方法");
}

require(['zepto','appCom','index','login'], function($,appCom,index,login) {

    hi:index.hi();
    show:index.show();
    say:login.say();
    hello:appCom.hello();
    return {
        MySelf:MySelf()
    }
});