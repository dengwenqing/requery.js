define([],function(require){
    function hello(){
        alert('Say Hello!');
    }
    return{
        hello: hello
    }
})