define([],function(require){
    function say(){
        alert('我是login模块中的方法!');
    }
    return{
        say:say
    }
})