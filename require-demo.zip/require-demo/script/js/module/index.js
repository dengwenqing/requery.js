define([],function(require){
    function hi(){
        alert('我在使用init暴露hi方法');
    };
    function show(){
        alert('我在使用init暴露show方法')
    };
    return{
        hi:hi,
        show:show
    }
})